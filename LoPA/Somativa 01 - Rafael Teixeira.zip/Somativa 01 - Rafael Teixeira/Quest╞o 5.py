print('Vamos fazer a tabuada de um número até 10!')
n = int(input('Digite um número: '))
for v in range(1, 10+1):
      print(f'{n} x {v} = {n * v}')
