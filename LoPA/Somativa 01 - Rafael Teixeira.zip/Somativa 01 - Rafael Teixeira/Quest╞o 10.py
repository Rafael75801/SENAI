print('Vamos calcular quanto tempo falta para você fazer 100 anos!')
idade = int(input('Me diga sua idade: '))
tempo = 100 - idade
print(f'Ainda faltam {tempo} anos para você fazer 100 anos')
