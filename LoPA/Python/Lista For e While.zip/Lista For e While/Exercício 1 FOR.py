"""
1 - Faça um programa que mostre na tela todos os números de 1 a 50 e depois essa
mesma lista invertida (50 a 1) usando laço for.
"""
for v in range(1, 50):
    print(v)
for a in range(50, 0, -1):
    print(a)
