"""
5 - Faça um programa para exibir a tabuada de 0 a 9.
"""

for i in range(0, 9+1):
    for v in range(0, 10+1):
        print(f'{i} * {v} = {i * v}')
